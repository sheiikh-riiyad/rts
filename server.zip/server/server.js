const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Allow your frontend to access this backend
app.use(cors({
  origin: ['https://wordpress.italyembassy.site', 'http://localhost:3000']
}));

app.use(express.json());

// Configure file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const passportNumber = req.body.passportNumber;
    if (!passportNumber) {
      return cb(new Error('Passport number is required'));
    }
    
    // Create folder with passport number
    const sanitizedPassport = passportNumber.replace(/[^a-zA-Z0-9]/g, '');
    const uploadDir = path.join(__dirname, 'uploads', sanitizedPassport);
    
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Keep original name but add timestamp
    const originalName = file.originalname;
    const extension = path.extname(originalName);
    const name = path.basename(originalName, extension);
    const finalName = `${name}_${Date.now()}${extension}`;
    cb(null, finalName);
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only JPG, PNG, and PDF files are allowed'));
    }
  }
});

// Test route
app.get('/', (req, res) => {
  res.json({ 
    message: 'RTS Server is running!',
    server: 'rts.italyembassy.site/server',
    port: PORT,
    status: 'Active'
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// File upload endpoint
app.post('/upload', upload.single('file'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        message: 'No file selected' 
      });
    }

    const sanitizedPassport = req.body.passportNumber.replace(/[^a-zA-Z0-9]/g, '');
    const filePath = `/uploads/${sanitizedPassport}/${req.file.filename}`;

    res.json({
      success: true,
      message: 'File uploaded successfully!',
      filePath: filePath,
      fileName: req.file.filename,
      originalName: req.file.originalname,
      fileSize: req.file.size,
      fileType: req.file.mimetype
    });

  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Upload failed: ' + error.message 
    });
  }
});

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Error handling
app.use((error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ 
        success: false, 
        message: 'File is too large. Maximum size is 10MB.' 
      });
    }
  }
  
  res.status(500).json({ 
    success: false, 
    message: error.message 
  });
});

// Start server
app.listen(PORT, 'localhost', () => {
  console.log('🚀 RTS Server started successfully!');
  console.log(`📍 Port: ${PORT}`);
  console.log(`📁 Folder: rts.italyembassy.site/server`);
  console.log(`🌐 Frontend: wordpress.italyembassy.site`);
  console.log(`✅ Ready for file uploads!`);
});